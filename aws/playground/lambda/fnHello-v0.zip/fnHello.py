
def Handler(event, context):
    print("Hello from Lambda!")

    return "Hello World!"